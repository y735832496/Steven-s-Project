package com.aig.dp.test.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;



/**异步任务组件
 * @author Allen
 *
 */
@Component
public class AsyncTask {
	
	@Autowired
    private  JavaMailSenderImpl mailSender;

	@Async
	public void sendEmail(String accountid, String password) {
		   SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
	        // 设置收件人，寄件人
	        simpleMailMessage.setTo(new String[] {"gangqin1278@163.com","zhangpenglmt@163.com"});
	        simpleMailMessage.setFrom("1075735226@qq.com");
	        simpleMailMessage.setSubject("Spring Boot Mail 邮件测试【文本】");
	        simpleMailMessage.setText("您的AccountId:"+accountid+"您的password:"+password);
	        // 发送邮件
	        mailSender.send(simpleMailMessage);

	        System.out.println("邮件已发送");		
	}

	

}
