package com.aig.dp.test.service;

public class DemoTest {

      public static void main(String[] args) {
         Integer aInteger=100;
         Integer bInteger=100;
         System.out.println(aInteger==bInteger);
		 	
		}
         
}


