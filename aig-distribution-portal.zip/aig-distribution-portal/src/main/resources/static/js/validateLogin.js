/*用户登录后校验每个页面的登陆情况*/
$(document).ready(function(){
	var User=JSON.parse(sessionStorage.getItem("user"));
	if(""==User||null==User){
		window.location.href="/app/dp/loginPage";
	}
		
})