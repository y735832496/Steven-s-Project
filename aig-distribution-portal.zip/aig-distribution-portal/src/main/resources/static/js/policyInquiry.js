$(function() {
		$("#headPic").click(function(){
			
			$("#upload").click();
			var objUrl = getObjectURL($('#headPic').get(0).src);
			alert(objUrl);
			if (objUrl) 
			{
				alert(objUrl);
				$("#headPic").attr("src",objUrl);		
			}
		});
	});
	
	function getObjectURL(file) {
	    var url = null ;
	    if (window.createObjectURL!=undefined) { // basic
	        url = window.createObjectURL(file) ;
	    } else if (window.URL!=undefined) { // mozilla(firefox)
	        url = window.URL.createObjectURL(file) ;
	    } else if (window.webkitURL!=undefined) { // webkit or chrome
	        url = window.webkitURL.createObjectURL(file) ;
	    }
	    return url ;
	}
	
	
