
function timeOutInterval(length) {
	setTimeout(function() {
		$(".marning").hide();
		$("#messageInfo").html("");
	}, length)
}

/*var context = [[@{/}]]; thymeleaf 获取项目路径的方式*/

var contextPath="/app";

//ajax调后台，
function commitAjax(actionUrl,json,callback)
{
	var contextPath="/app";
	var url=contextPath+actionUrl;
	$.ajax({
		url : url,
		type : "POST",
		//dataType: "text", //数据格式:JSON  json text
		contentType: "application/json",
		data : json, //提交数据
		timeout:60000,
		error : function(XMLHttpRequest,	textStatus,	errorThrown) {
			alert("网络超时，请稍后重试 "+textStatus +" - "  + errorThrown);
			console.log("----> "+textStatus + +errorThrown);
		},
		success : function(	data,status) {
			if(data)
				{
					console.log("---->server success  "+status);
					callback(data);
				}
		}
	});
}


  //获取两个日期相差几天
 function getDifferDays(date1,date2){
	var thisDate=Date.parse(date1);   
	var thatDate=Date.parse(date2);    
	var totalMillis=thisDate-thatDate; 
	var days=totalMillis/(1000*60*60*24);
	return days;
}
  //模态框
 function warnMessage(message){
	    //墨绿深蓝风
		layer.alert(message, 
		{
		skin: 'layui-layer-molv' //样式类名
		,closeBtn: 0
		});
	}
 

