package com.aig.dp.dao.sqlserver.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aig.dp.dao.sqlserver.po.UserPO;
import com.aig.dp.service.vo.UserVO;


public interface UserMapper { 
    public List<UserPO> getPersons() throws Exception;
    
    public UserPO getPersonsByID(int id) throws Exception;

	public void insertUser(@Param("accountid")String accountid,@Param("name") String name,@Param("branch")String branch, @Param("position")String position, @Param("alternativeposition")String alternativeposition, @Param("employeeno")String employeeno,
			@Param("contactno")String contactno, @Param("email")String email, @Param("qualification")String qualification,@Param("producerCode")String producerCode,@Param("team") String team, @Param("assitantManager")String assitantManager,@Param("password") String password,@Param("roleID") String roleID,@Param("isValid")String isValid);

	public UserVO userLogin(@Param("accountid")String accountid, @Param("password")String password);

	public void userModifyPwd(@Param("accountid")String accountid, @Param("password")String password);

	public UserVO userForgetIDorPWD(@Param("accountid")String accountid, @Param("email")String email);

	public UserVO cherckUser(@Param("accountid")String accountid);


}