package com.aig.dp.service.index;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aig.dp.dao.sqlserver.mapper.GroupPccMapper;
import com.aig.dp.service.vo.UserVO;

@Service
public class GroupPccService {
@Autowired
GroupPccMapper dao;

public ArrayList<UserVO> doSearch(String position,String branch,String employeeId,String inputBranch
		,String inputFullName,String inputEmployeeId,String inputTeam){
	ArrayList<UserVO> list = new ArrayList<UserVO>();
	if(position.equals("assistant"))
	{
		list=dao.doSearchForAssistant(position,branch,employeeId,inputBranch,inputFullName,inputEmployeeId,inputTeam);
	}
	else if(position.equals("teamManager"))
	{
		list=dao.doSearchForTM(position,branch,employeeId,inputBranch,inputFullName,inputEmployeeId,inputTeam);
	}
	else if(position.equals("GM"))
	{
		list=dao.doSearchForGM(position,branch,employeeId,inputBranch,inputFullName,inputEmployeeId,inputTeam);
	}
	else
	{
		list=dao.doSearchForAdmin(position,branch,employeeId,inputBranch,inputFullName,inputEmployeeId,inputTeam);
	}
	return list;
}


}
