package com.aig.dp.dao.sqlserver.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aig.dp.service.vo.EmpInfoVO;

public interface EmpInfoSearch {
//	public ArrayList<EmpInfoVO> searchEmpInfo(@Param("accountid") String accountid);
	public ArrayList<EmpInfoVO> searchEmpInfo(@Param("accountid") String accountid,@Param("empName") String empName);

	public List queryUserByMuiltfield(String accountId, String name, String branch, String team, String premium, String status,
			String annual);
}
