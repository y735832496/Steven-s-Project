package com.aig.dp.service.index;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aig.dp.dao.sqlserver.mapper.GroupInfoSearchMapper;
import com.aig.dp.service.vo.UserVO;

@Service
public class GroupInfoService {
@Autowired
protected GroupInfoSearchMapper dao; 
	
	public ArrayList<UserVO> empSearch(String name,String employeeNo,String branch,String team,String annual){
		ArrayList<UserVO> list = new ArrayList<UserVO>();
		list=dao.empSearch(name,employeeNo,branch,team,annual);
		return list;
	}
}
