package com.aig.dp.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.aig.dp.common.uibinding.BaseResponse;
import com.aig.dp.service.index.IndexService;
import com.aig.dp.service.vo.UserVO;


/**
 * @author 686344
 *
 */
@Controller
@RequestMapping("/dp")
public class IndexController {
	
	@Autowired
	protected IndexService service;
	
	/**
	 * 跳转页面 传数据方法
	 * @param model
	 * @return
	 * @throws Exception 
     */
	@RequestMapping("/index")
	public String index(Model model) throws Exception {
		UserVO obj=service.getPersonsByID();
		model.addAttribute("person",obj);
		//返回 index.html页面
		return "index" ;
		
	}
	
	
	
	@RequestMapping("/home")
	public String home() throws Exception {
	    throw new Exception("this is a test exception");
	}
	
	
	@RequestMapping("/mainPage")
	public String mainPage() throws Exception {
		return "mainPage";
	}
	
	
	/**注册页面
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/registerPage")	
	public String userRegister(Model model) throws Exception {
		return "register";
	}	 
	
	 
		/**
		 * 显示员工信息界面
		 * @param model
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/infoPage")	
		public String test(Model model) throws Exception {
			return "empInfo";
		}	
	
	/**登录页面
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/loginPage")	
	public String userLogin(Model model) throws Exception {
		return "login";
	}	
	
	
	/**忘记密码
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/forgetPage")	
	public String userForget(Model model) throws Exception {
		return "forgetPwd"; 
	}	 

	/**
	 * 更新员工
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/UpdateEmp")	
	public String changeEmp(Model model) throws Exception {
		return "changeEmpInfo"; 
	}	 

	/**修改密码
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/changePwd")	
	public String changePwd(Model model) throws Exception {
		return "changePwd";
	}	
	

	
	/**个人信息页面
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/empInfoPage")	
	public String empInfoPage(Model model) throws Exception {
		return "empInfo";
	}	
	
	/**团队页面
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/teamPage")	
	public String teamPage(Model model) throws Exception {
		return "teamPage";
	}	
	
	
	/**管理员修改员工信息
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/adminModifyPwd")	
	public String adminModifyPwd(Model model) throws Exception {
		return "changeEmpInfo";
	}	
	
	
	/**
	 * 我的总裁杯
	 * @author 686344
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/myPCC")	
	public String myPCC(Model model) throws Exception {
		return "myPCC";
	}	
	/**
	 * 团队总裁杯
	 * @author 686344
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/groupPCC")	
	public String groupPCC(Model model) throws Exception {
		return "groupPCC";
	}	
	
	/**
	 * 保单检索
	 * @author 686344
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/policySearch")	
	public String policySearch(Model model) throws Exception {
		List<UserVO> userVO = new ArrayList<UserVO>();
		UserVO user = new UserVO();				
		user.setName("Steven");
		user.setBranch("Insurance");
		UserVO user2 = new UserVO();
		user2.setName("Test");
		user2.setBranch("Matelife");
		userVO.add(user);
		userVO.add(user2);
		userVO.add(user);
		userVO.add(user2);
		userVO.add(user);
		userVO.add(user2);
		System.out.println(user2.getClass());
		model.addAttribute("userInfo",userVO);
		return "policyInquiry";
	}	
}

