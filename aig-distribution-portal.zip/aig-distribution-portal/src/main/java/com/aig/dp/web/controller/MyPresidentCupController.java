package com.aig.dp.web.controller;

import java.util.HashMap;
import java.util.Map;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aig.dp.common.uibinding.BaseResponse;
import com.aig.dp.common.util.JsonUtils;
import com.aig.dp.service.index.MyPresidentCampaignService;
import com.aig.dp.service.vo.PresidentCupVO;

@Controller
public class MyPresidentCupController {
	@Autowired
	MyPresidentCampaignService service;
	/**
	 * 我的总裁杯   PCC=总裁杯
	 * @author 686344
	 * @param inputJSON
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/myPCC",method=RequestMethod.POST)
	@ResponseBody
	public BaseResponse myPCC(@RequestBody String inputJSON) throws Exception{
		String branch=JsonUtils.getValueByKey(inputJSON, "branch");
		String employeeNo = JsonUtils.getValueByKey(inputJSON, "employeeNo");
		String team = JsonUtils.getValueByKey(inputJSON, "team");
		BaseResponse baseResponse = new BaseResponse();
		PresidentCupVO pcVO = new PresidentCupVO();
		service.myPCC(branch, team, employeeNo);
		
		/*if(pcVO){
			baseResponse.setMessage("您所在团队中无成员");
			baseResponse.setCode("998");
		}
		else {
			baseResponse.setMessage("检索成功");
			baseResponse.setCode("000");
		}
		baseResponse.setObject(list);*/
		return baseResponse;
	}
}
