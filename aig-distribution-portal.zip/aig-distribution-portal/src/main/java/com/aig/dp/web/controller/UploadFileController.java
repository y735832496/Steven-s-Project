package com.aig.dp.web.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;



@Controller
public class UploadFileController {
	
	
	public static final String path="D:\\aig\\aig-distribution-portal\\src\\main\\resources\\static\\img";

	@RequestMapping(value = "/upload",method=RequestMethod.POST)
	public String uploadFile(@RequestParam("file") MultipartFile  file) throws IllegalStateException, IOException {
		String filename=file.getOriginalFilename();
		int size=(int) file.getSize();
		String fileType=file.getContentType();
		System.out.println("文件名："+filename+",文件大小："+size+",文件类型："+fileType);
		file.transferTo(new File(path));
		
       return "";
	}
}
