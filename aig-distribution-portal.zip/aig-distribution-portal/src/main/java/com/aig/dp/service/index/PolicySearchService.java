package com.aig.dp.service.index;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aig.dp.dao.sqlserver.mapper.PolicySearchMapper;
import com.aig.dp.service.vo.PolicyInfoVO;

@Service
public class PolicySearchService {
	@Autowired
	PolicySearchMapper dao;
	
	public ArrayList<PolicyInfoVO> policySearch(String branch, String name, String team, String channel,
			String majorLine, String minorLine, String policyCode,String userBranch, String userEmployeeNo,String userTeam,String userPosition) {
		ArrayList<PolicyInfoVO> list = new ArrayList<PolicyInfoVO>();
		//list = dao.policySearch(branch,name,team,channel,majorLine,minorLine,policyCode);
		if(userPosition.toLowerCase().equals("add") || userPosition.toLowerCase().equals("cbe") ||userPosition.toLowerCase().equals("ds"))
		{
			list=dao.policySearch(branch,name,team,channel,majorLine,minorLine,policyCode,userBranch,userEmployeeNo,userTeam,userPosition);
		}
		else if(userPosition.toLowerCase().equals("assistant"))
		{
			list=dao.policySearch(branch,name,team,channel,majorLine,minorLine,policyCode,"","","",userPosition);
		}
		else if(userPosition.toLowerCase().equals("teammanager"))
		{
			list=dao.policySearch(branch,name,team,channel,majorLine,minorLine,policyCode,"","",userTeam,"");
		}
		else if(userPosition.toLowerCase().equals("gm"))
		{
			list=dao.policySearch(branch,name,team,channel,majorLine,minorLine,policyCode,userBranch,"","","");
		}
		else
		{
			list=dao.policySearch(branch,name,team,channel,majorLine,minorLine,policyCode,"","","","");
		}
		
	
		return list;

	}

}
