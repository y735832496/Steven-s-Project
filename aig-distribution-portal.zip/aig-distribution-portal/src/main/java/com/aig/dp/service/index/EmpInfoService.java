package com.aig.dp.service.index;

import com.aig.dp.dao.sqlserver.mapper.EmpInfoSearchMapper;
import com.aig.dp.service.vo.EmpInfoVO;
import com.aig.dp.service.vo.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class EmpInfoService {

	@Autowired
	protected EmpInfoSearchMapper dao;

	public ArrayList<EmpInfoVO> searchEmp(String empAccountID) {
//		ArrayList<EmpInfoVO> vo = new ArrayList<EmpInfoVO>();
//		if (!empAccountID.equals("")) {
//			vo = dao.searchEmpInfo(empAccountID);
//		}
//		return vo;
		return null;
	}


	public List queryUserByMuiltfield(String accountId, String name, String branch, String team, String premium,
		String status, String annual) {
//		List userList=new ArrayList();
//		try {
//			 userList=dao.queryUserByMuiltfield(accountId,name,branch,team,premium,status,annual);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		return null;
	}

	public UserVO modifyEmpInfo(String accountId) {
		UserVO userVO=new UserVO();
		try {
			userVO=dao.modifyEmpInfo(accountId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userVO;
	}
	public void updateEmpInfo(String accountId,String name,String branch,String position,String employeeNo,
			String contactNo,String email,String qualification,String team)
	{
		dao.updateEmpInfo(accountId, name, branch, position, employeeNo, contactNo, email, qualification, team);
	}
	
	public ArrayList<UserVO> teamMemberSearch(String team)
	{
		ArrayList<UserVO> list = new ArrayList<UserVO>();
		list=dao.teamMemberSearch(team);
		return list;
	}
}
