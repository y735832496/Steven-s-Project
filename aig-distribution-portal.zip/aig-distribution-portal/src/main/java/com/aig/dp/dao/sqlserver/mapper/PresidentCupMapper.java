package com.aig.dp.dao.sqlserver.mapper;

import org.apache.ibatis.annotations.Param;

import com.aig.dp.service.vo.PresidentCupVO;

public interface PresidentCupMapper {
	public PresidentCupVO myPresidentCupSearch(@Param("branch")String branch,@Param("team")String team,@Param("employeeNo")String employeeNo);
}
