package com.aig.dp.web.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aig.dp.common.uibinding.BaseResponse;
import com.aig.dp.common.util.JsonUtils;
import com.aig.dp.service.index.PolicySearchService;
import com.aig.dp.service.vo.PolicyInfoVO;

@Controller
public class PolicySearchController {

	@Autowired
	PolicySearchService service;

	@RequestMapping(value = "/policySearch", method = RequestMethod.POST)
	@ResponseBody
	public BaseResponse policySearch(@RequestBody String inputJson) throws Exception {
		String branch = JsonUtils.getValueByKey(inputJson, "branch");
		String name = JsonUtils.getValueByKey(inputJson, "name");
		String team = JsonUtils.getValueByKey(inputJson, "team");
		String channel = JsonUtils.getValueByKey(inputJson, "channel");
		String majorLine = JsonUtils.getValueByKey(inputJson, "majorLine");
		String minorLine = JsonUtils.getValueByKey(inputJson, "minorLine");
		String policyCode = JsonUtils.getValueByKey(inputJson, "policyCode");
		String userBranch = JsonUtils.getValueByKey(inputJson, "userBranch");
		String userEmployeeNo = JsonUtils.getValueByKey(inputJson, "userEmployeeNo");
		String userTeam = JsonUtils.getValueByKey(inputJson, "userTeam");
		String userPosition = JsonUtils.getValueByKey(inputJson, "userPosition");
		ArrayList<PolicyInfoVO> list = new ArrayList<PolicyInfoVO>();
		BaseResponse response = new BaseResponse();
		try {
			list = service.policySearch(branch, name, team, channel, majorLine, minorLine, policyCode, userBranch,
					userEmployeeNo, userTeam, userPosition);
		} catch (Exception e) {
			response.setCode("999");
			response.setMessage("检索异常");
			return response;
		}
		
		if (list.isEmpty()) {
			response.setCode("998");
			return response;
		} else {
			response.setCode("000");
			response.setMessage("检索成功");
			response.setObject(list);
			return response;
		}
	}

}
