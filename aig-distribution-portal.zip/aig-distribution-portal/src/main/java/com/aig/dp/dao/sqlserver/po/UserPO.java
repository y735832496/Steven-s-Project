package com.aig.dp.dao.sqlserver.po;

import java.util.Date;

/**
 * 描述：实体类
 *
 * @author
 * @create_time
 */
public class UserPO {
	private int ID;
	private String AccountID;
	private String Name;
	private String Branch;
	private String Position;
	private String AlternativePosition;
	private String EmployeeNo;
	private String ContactNo;
	private String EmailAccount;
	private String AgentQualificationNo;
	private String ProducerCode;
	private String Team;
	private String AssitantManager;
	private String Password;
	private String RoleID;
	private Date StatusSubmitDate;
	private Date StatusActiveDate;
	private Date StatusFirstChangePwdDate;
	private Date StatusInitPwdDate;
	private Date StatusUpdatePwdDate;
	private String IsValid;
	private Date UpdateDate;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getAccountID() {
		return AccountID;
	}
	public void setAccountID(String accountID) {
		AccountID = accountID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getBranch() {
		return Branch;
	}
	public void setBranch(String branch) {
		Branch = branch;
	}
	public String getPosition() {
		return Position;
	}
	public void setPosition(String position) {
		Position = position;
	}
	public String getAlternativePosition() {
		return AlternativePosition;
	}
	public void setAlternativePosition(String alternativePosition) {
		AlternativePosition = alternativePosition;
	}
	public String getEmployeeNo() {
		return EmployeeNo;
	}
	public void setEmployeeNo(String employeeNo) {
		EmployeeNo = employeeNo;
	}
	public String getContactNo() {
		return ContactNo;
	}
	public void setContactNo(String contactNo) {
		ContactNo = contactNo;
	}
	public String getEmailAccount() {
		return EmailAccount;
	}
	public void setEmailAccount(String emailAccount) {
		EmailAccount = emailAccount;
	}
	public String getAgentQualificationNo() {
		return AgentQualificationNo;
	}
	public void setAgentQualificationNo(String agentQualificationNo) {
		AgentQualificationNo = agentQualificationNo;
	}
	public String getTeam() {
		return Team;
	}
	public void setTeam(String team) {
		Team = team;
	}
	public String getAssitantManager() {
		return AssitantManager;
	}
	public void setAssitantManager(String assitantManager) {
		AssitantManager = assitantManager;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getRoleID() {
		return RoleID;
	}
	public void setRoleID(String roleID) {
		RoleID = roleID;
	}
	public Date getStatusSubmitDate() {
		return StatusSubmitDate;
	}
	public void setStatusSubmitDate(Date statusSubmitDate) {
		StatusSubmitDate = statusSubmitDate;
	}
	public Date getStatusActiveDate() {
		return StatusActiveDate;
	}
	public void setStatusActiveDate(Date statusActiveDate) {
		StatusActiveDate = statusActiveDate;
	}
	public Date getStatusFirstChangePwdDate() {
		return StatusFirstChangePwdDate;
	}
	public void setStatusFirstChangePwdDate(Date statusFirstChangePwdDate) {
		StatusFirstChangePwdDate = statusFirstChangePwdDate;
	}
	public Date getStatusInitPwdDate() {
		return StatusInitPwdDate;
	}
	public void setStatusInitPwdDate(Date statusInitPwdDate) {
		StatusInitPwdDate = statusInitPwdDate;
	}
	public Date getStatusUpdatePwdDate() {
		return StatusUpdatePwdDate;
	}
	public void setStatusUpdatePwdDate(Date statusUpdatePwdDate) {
		StatusUpdatePwdDate = statusUpdatePwdDate;
	}
	public String getIsValid() {
		return IsValid;
	}
	public void setIsValid(String isValid) {
		IsValid = isValid;
	}
	public Date getUpdateDate() {
		return UpdateDate;
	}
	public void setUpdateDate(Date updateDate) {
		UpdateDate = updateDate;
	}
	public String getProducerCode() {
		return ProducerCode;
	}
	public void setProducerCode(String producerCode) {
		ProducerCode = producerCode;
	}

}
