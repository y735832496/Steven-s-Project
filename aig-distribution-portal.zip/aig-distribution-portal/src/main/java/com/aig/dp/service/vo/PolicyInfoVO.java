package com.aig.dp.service.vo;

/**
 * For BR 6.7
 * policySearch
 * @author 686344
 *
 */
public class PolicyInfoVO {
private String branch;
private String policyNo;
private String effectiveDate;
private String expireDate;
private String submissionDate;
private String commission;
private String premium;
private String currency;
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public String getPolicyNo() {
	return policyNo;
}
public void setPolicyNo(String policyNo) {
	this.policyNo = policyNo;
}
public String getEffectiveDate() {
	return effectiveDate;
}
public void setEffectiveDate(String effectiveDate) {
	this.effectiveDate = effectiveDate;
}
public String getExpireDate() {
	return expireDate;
}
public void setExpireDate(String expireDate) {
	this.expireDate = expireDate;
}
public String getSubmissionDate() {
	return submissionDate;
}
public void setSubmissionDate(String submissionDate) {
	this.submissionDate = submissionDate;
}
public String getCommission() {
	return commission;
}
public void setCommission(String commission) {
	this.commission = commission;
}
public String getPremium() {
	return premium;
}
public void setPremium(String premium) {
	this.premium = premium;
}
public String getCurrency() {
	return currency;
}
public void setCurrency(String currency) {
	this.currency = currency;
}

}
