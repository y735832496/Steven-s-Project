package com.aig.dp.web.controller;

public class UserResources {

}
