package com.aig.dp.service.vo;

public class PresidentCupVO {
	private String id;
	private String branch;
	private String team;
	private String DSAEName;
	private String level;
	private String GPWGrowth;
	private String actualSinglePresidentCup;
	private String expectedSinglePresidentCup;
	private String actualDoublePresidentCup;
	private String expectedDoublePresidentCup;
	private String employeeNo;
	private String uploadId;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getDSAEName() {
		return DSAEName;
	}
	public void setDSAEName(String dSAEName) {
		DSAEName = dSAEName;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getGPWGrowth() {
		return GPWGrowth;
	}
	public void setGPWGrowth(String gPWGrowth) {
		GPWGrowth = gPWGrowth;
	}
	public String getActualSinglePresidentCup() {
		return actualSinglePresidentCup;
	}
	public void setActualSinglePresidentCup(String actualSinglePresidentCup) {
		this.actualSinglePresidentCup = actualSinglePresidentCup;
	}
	public String getExpectedSinglePresidentCup() {
		return expectedSinglePresidentCup;
	}
	public void setExpectedSinglePresidentCup(String expectedSinglePresidentCup) {
		this.expectedSinglePresidentCup = expectedSinglePresidentCup;
	}
	public String getActualDoublePresidentCup() {
		return actualDoublePresidentCup;
	}
	public void setActualDoublePresidentCup(String actualDoublePresidentCup) {
		this.actualDoublePresidentCup = actualDoublePresidentCup;
	}
	public String getExpectedDoublePresidentCup() {
		return expectedDoublePresidentCup;
	}
	public void setExpectedDoublePresidentCup(String expectedDoublePresidentCup) {
		this.expectedDoublePresidentCup = expectedDoublePresidentCup;
	}
	public String getEmployeeNo() {
		return employeeNo;
	}
	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}
	public String getUploadId() {
		return uploadId;
	}
	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}
	
}
