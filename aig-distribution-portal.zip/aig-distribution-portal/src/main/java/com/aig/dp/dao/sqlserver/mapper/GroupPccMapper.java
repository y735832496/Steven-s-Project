package com.aig.dp.dao.sqlserver.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.aig.dp.service.vo.UserVO;

public interface GroupPccMapper {
 public ArrayList<UserVO> doSearchForAssistant(@Param("position")String position,@Param("branch")String branch,@Param("employeeId")String employeeId,@Param("inputBranch")String inputBranch
			,@Param("inputFullName")String inputFullName,@Param("inputEmployeeId")String inputEmployeeId,@Param("inputTeam")String inputTeam);
 public ArrayList<UserVO> doSearchForTM(@Param("position")String position,@Param("branch")String branch,@Param("employeeId")String employeeId,@Param("inputBranch")String inputBranch
			,@Param("inputFullName")String inputFullName,@Param("inputEmployeeId")String inputEmployeeId,@Param("inputTeam")String inputTeam);
 public ArrayList<UserVO> doSearchForGM(@Param("position")String position,@Param("branch")String branch,@Param("employeeId")String employeeId,@Param("inputBranch")String inputBranch
			,@Param("inputFullName")String inputFullName,@Param("inputEmployeeId")String inputEmployeeId,@Param("inputTeam")String inputTeam);
 public ArrayList<UserVO> doSearchForAdmin(@Param("position")String position,@Param("branch")String branch,@Param("employeeId")String employeeId,@Param("inputBranch")String inputBranch
			,@Param("inputFullName")String inputFullName,@Param("inputEmployeeId")String inputEmployeeId,@Param("inputTeam")String inputTeam);
}
