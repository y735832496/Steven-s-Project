package com.aig.dp.common.util;

import java.math.BigDecimal;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;


 
public class StringUtils {
	public static <T> boolean listNotValue(List<T> list) {
		if (list != null && list.size() > 0) {
			return true;
		}
		return false;
	}
	
	public static String listToString(List<String> list) {
		String result = "";
		if (listNotValue(list)) {
			for (String str : list) {
				result += str + ",";
			}
		}
		
		return result;
	}
	
	
	public static String stringToTrim(String item) {
		if(!isEmpty(item)) {
			return  item.trim();
		}
		return item;
	}
	
	public static boolean isEmpty(String arg) {
		if (arg == null || arg.trim().length() < 1) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static String Empty() {
		return "";
	}
	
	public static String bytes2Hex(byte[] bts) {
        String des = "";
        String tmp = null;
        for (int i = 0; i < bts.length; i++) {
            tmp = (Integer.toHexString(bts[i] & 0xFF));
            if (tmp.length() == 1) {
                des += "0";
            }
            des += tmp;
        }
        return des.toUpperCase();
    }
	
	public static String empttyToNull(String str)
	{
		if(isEmpty(str))
		{
			return null;
		}
		else
		{
			return str;
		}
	}
	
	public static boolean isEmpty(Object str) {
		
		return (str==null||"".equals(str));
		
	}
	
	public static String toStringByObject(Object obj) {
		if(null==obj) {
			return "";
		}				
		return obj.toString();
	}
	public static  String Calculate(Object  maxValue,Object value  ) {
		BigDecimal minValue = BigDecimal.ZERO;
		if(maxValue!=null && value!=null) {
			minValue = ((BigDecimal) maxValue).subtract((BigDecimal) value) ;
		}		
		String retnStr = "";
		if(minValue .compareTo(BigDecimal.ZERO)<0)
			retnStr = "0.";
		else  retnStr = minValue.toString();
		
		return retnStr;
	}
	
	 public static String getRandom()
	    {
	    	Random random = new Random();
	    	String result="";
	    	for (int i=0;i<6;i++)
	    	{
	    		result+=random.nextInt(10);
	    	}
	        return result;

	    }
	
	/*public static void main(String[] args) {
		
		String ss=StringUtils.getRandom();
		System.out.println(ss);
	}*/
	
}

