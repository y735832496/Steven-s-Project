package com.aig.dp.common.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;



public class JsonUtils {


	public static String getValueByKey(String json, String key) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		Map map = mapper.readValue(json, Map.class);
		return (String) map.get(key);
	}
	
	public static Map getMapByJson(String json) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		Map map = mapper.readValue(json, Map.class);
		return map;
	}
	
	public static String toJsonByObject(Object object) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(object);
		return json;
	}
	
	/*public static String formatDateAndStringValue(JsonResponse response) throws Exception {
		if(response.getData() instanceof java.util.List) {
			for (Object object : (List)response.getData()) {
				beanAttributeValueTrim(object);
			}
		}else {
			beanAttributeValueTrim(response.getData());
		}
		return formatDateValue(response, "yyyy-MM-dd HH:mm:ss");
	}*/
	
/*	public static String formatDateValue(JsonResponse response, String date_pattern) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		SimpleDateFormat dateFormat = new SimpleDateFormat(date_pattern);
		mapper.setDateFormat(dateFormat);
		return mapper.writeValueAsString(response);
	}*/
	
	
	public static Object formatStringValue(Object data) throws Exception {
		if(data instanceof java.util.List) {
			for (Object object : (List)data) {
				beanAttributeValueTrim(object);
			}
		}else if(data instanceof java.util.Map){
			Map<String, Object> map = (Map<String, Object>) data;
			for (String key : map.keySet()) {
				Object value = map.get(key);
				if (value instanceof java.lang.String) {
					if (value == null)
						continue;
					map.put(key, value.toString().trim());
				}
			}
		}else {
			beanAttributeValueTrim(data);
		}
		return data;
	}
	
	public static void beanAttributeValueTrim(Object bean) throws Exception {
		if (bean != null) {
			Field[] fields = bean.getClass().getDeclaredFields();
			for (int i = 0; i < fields.length; i++) {
				Field f = fields[i];
				if (f.getType().getName().equals("java.lang.String")) {
					String key = f.getName();
					Object value = getFieldValue(bean, key);
					if (value == null)
						continue;
					setFieldValue(bean, key, value.toString().trim());
				}
			}
		}
	} 
	  
	public static Object getFieldValue(Object bean, String fieldName) throws Exception {
		StringBuffer result = new StringBuffer();
		String methodName = result.append("get").append(fieldName.substring(0, 1).toUpperCase())
				.append(fieldName.substring(1)).toString();
		Object rObject = null;
		Method method = null;
		Class[] classArr = new Class[0];
		method = bean.getClass().getMethod(methodName, classArr);
		rObject = method.invoke(bean, new Object[0]);
		return rObject;
	} 
	
	private static void setFieldValue(Object bean, String fieldName, Object value) throws Exception {
		StringBuffer result = new StringBuffer();
		String methodName = result.append("set").append(fieldName.substring(0, 1).toUpperCase())
				.append(fieldName.substring(1)).toString();
		Class[] classArr = new Class[1];
		classArr[0] = "java.lang.String".getClass();
		Method method = bean.getClass().getMethod(methodName, classArr);
		method.invoke(bean, value);
	} 
	
}
