package com.aig.dp.dao.sqlserver.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.aig.dp.service.vo.PolicyInfoVO;

public interface PolicySearchMapper {

	public ArrayList<PolicyInfoVO> policySearch(@Param("branch")String branch
			, @Param("name")String name, @Param("team")String team, @Param("channel")String channel
			,@Param("majorLine") String majorLine,@Param("minorLine")String minorLine,
			@Param("policyCode") String policyCode,@Param("userBranch") String userBranch
			,@Param("userEmployeeNo")String userEmployeeNo,@Param("userTeam") String userTeam,
			@Param("userPosition") String userPosition);
}
