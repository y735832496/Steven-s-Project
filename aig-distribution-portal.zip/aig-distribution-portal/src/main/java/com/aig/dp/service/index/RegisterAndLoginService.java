package com.aig.dp.service.index;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aig.dp.common.uibinding.BaseResponse;
import com.aig.dp.common.util.StringUtils;
import com.aig.dp.dao.sqlserver.mapper.UserMapper;
import com.aig.dp.service.BaseService;
import com.aig.dp.service.vo.UserVO;

@Service
public class RegisterAndLoginService extends BaseService{
	
	@Autowired
	protected UserMapper dao;
	
	/*@Autowired
	protected AsyncTask asyncTask;
*/
	public void insertUser(String accountid, String name, String branch, String position, String employeeno,
			String contactno, String email, String qualification, String team) throws IOException {
		/*这里可以做后端的判断和验证操作*/		
		String password = "init"+StringUtils.getRandom();//生成一个初始密码
		String alternativePosition="";
		String assitantManager="";//主管manager
		String roleID="";
		String isValid="false";//登录权限
		String producerCode="";
		dao.insertUser(accountid,name,branch,position,alternativePosition,employeeno,contactno,email,qualification,producerCode,team,assitantManager,password,roleID,isValid);
		//asyncTask.sendEmail(accountid,password);//异步发送邮件
	}

	public UserVO userLogin(String accountId, String password) {
		UserVO  user_V=dao.userLogin(accountId,password);
		return  user_V;
	}

	public void userModifyPwd(String accountid, String password) {
		dao.userModifyPwd(accountid,password);
		
	}

	public BaseResponse userForgetIDorPWD(String accountId, String email) {
		BaseResponse  response=new 	BaseResponse();
		UserVO userVO =dao.cherckUser(accountId);
		if(StringUtils.isEmpty(userVO)) {
			response.setCode("999");
			response.setMessage("此用户不存在");
		}else {
			UserVO  user_V=dao.userForgetIDorPWD(accountId,email);
			if(!StringUtils.isEmpty(user_V)) {
				String password = "init"+StringUtils.getRandom();//生成一个初始密码	
				//asyncTask.sendEmail(user_V.getAccountID(),password);//异步发送邮件
				response.setCode("000");
				response.setMessage("账号信息请查收邮件");
			}else {
				response.setCode("999");
				response.setMessage("邮箱与员工号不匹配");
			}
		}
		
		return response;
	}

	public UserVO cherckUser(String accountid) {
		UserVO userVO =dao.cherckUser(accountid);
		return userVO;
	}

}
