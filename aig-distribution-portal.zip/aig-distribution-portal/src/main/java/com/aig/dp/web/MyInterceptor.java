package com.aig.dp.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Servlet implementation class MyInterceptor
 */

public class MyInterceptor implements HandlerInterceptor {
	
	@Override
	public boolean preHandle(HttpServletRequest request,HttpServletResponse response,Object object  ) throws Exception {
	/*	System.out.println(request.getRequestURI().toString()+"Test interceptor");
		if(request.getRequestURI().toString().equals("/app/dp/policySearch"))
		{
			response.getWriter().write("<font color='Green' size='25'>Please wait...</font>");
			response.setHeader("Refresh","5;URL="+"/app/dp/mainPage");
		}  */
		return true;
	}
		
	@Override
	public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
		System.out.println("afterCompletion被调用 Test interceptor");
	}
	


}
