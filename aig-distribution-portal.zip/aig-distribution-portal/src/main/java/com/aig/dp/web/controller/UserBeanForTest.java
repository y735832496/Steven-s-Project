package com.aig.dp.web.controller;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserBeanForTest {


		private int userID;
		private String name;
		private int age;
		public int getUserID() {
			return userID;
		}
		public void setUserID(int userID) {
			this.userID = userID;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}


}
