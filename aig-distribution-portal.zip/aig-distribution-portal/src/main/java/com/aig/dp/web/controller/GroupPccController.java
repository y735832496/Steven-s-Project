package com.aig.dp.web.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aig.dp.common.uibinding.BaseResponse;
import com.aig.dp.common.util.JsonUtils;
import com.aig.dp.service.index.GroupPccService;
import com.aig.dp.service.vo.UserVO;

@Controller
public class GroupPccController {
@Autowired
GroupPccService service;

@RequestMapping(value="/groupPCCSearch",method=RequestMethod.POST)
@ResponseBody
public BaseResponse doSearch(@RequestBody String inputJson) throws Exception {
	String position = JsonUtils.getValueByKey(inputJson, "position");
	String branch = JsonUtils.getValueByKey(inputJson, "branch");
	String employeeId = JsonUtils.getValueByKey(inputJson, "employeeId");
	String inputTeam = JsonUtils.getValueByKey(inputJson, "inputTeam");
	String inputBranch =  JsonUtils.getValueByKey(inputJson, "inputBranch");
	String inputFullName = JsonUtils.getValueByKey(inputJson, "inputFullName");
	String inputEmployeeId = JsonUtils.getValueByKey(inputJson, "inputEmployeeId");
	ArrayList<UserVO> list = new ArrayList<UserVO>();	
	BaseResponse response = new BaseResponse();
	try {
		list= service.doSearch(position,branch,employeeId,inputBranch,inputFullName,inputEmployeeId,inputTeam);
		response.setObject(list);
		response.setMessage("检索成功");
		response.setCode("000");
	}
	catch(Exception e) {
		e.printStackTrace();
		response.setCode("999");
		response.setMessage("检索失败！");
	}
	if(list.isEmpty())
	{
		response.setCode("998");
		response.setMessage("无结果");
	}
	return response;
}
}
