package com.aig.dp.common.uibinding;

import com.aig.dp.common.util.JsonUtils;

public class BaseResponse {
    protected String code;
    protected String message;
    protected Object object;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void setObject(Object object) throws Exception {
		this.object = JsonUtils.formatStringValue(object);
	}
	
	public Object getObject() {
		return object;
	}
	public void setCodeMessage(String key,String msg)
	{
		this.code=key;
		this.message=msg;
	}
    
}
