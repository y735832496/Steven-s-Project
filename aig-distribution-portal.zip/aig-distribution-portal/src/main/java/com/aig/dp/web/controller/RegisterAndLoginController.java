package com.aig.dp.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aig.dp.common.uibinding.BaseResponse;
import com.aig.dp.common.util.JsonUtils;
import com.aig.dp.common.util.StringUtils;
import com.aig.dp.service.index.RegisterAndLoginService;
import com.aig.dp.service.vo.UserVO;

/**
 * @author 627944
 * Allen
 */
@RestController
public class RegisterAndLoginController {
		

	@Autowired
	protected RegisterAndLoginService service;
	
	
	/**用户注册
	 * @param inputJson
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/register",method = RequestMethod.POST)	
	public  BaseResponse userRegister(@RequestBody String inputJson) throws Exception {		
		String accountid=JsonUtils.getValueByKey(inputJson, "accountid");
		String name=JsonUtils.getValueByKey(inputJson, "name");
		String branch=JsonUtils.getValueByKey(inputJson, "branch");
		String position=JsonUtils.getValueByKey(inputJson, "position");
		String employeeno=JsonUtils.getValueByKey(inputJson, "employeeno");
		String contactno=JsonUtils.getValueByKey(inputJson, "contactno");
		String email=JsonUtils.getValueByKey(inputJson, "email");
		String qualification=JsonUtils.getValueByKey(inputJson, "qualification");
		String team=JsonUtils.getValueByKey(inputJson, "team");
		BaseResponse  response=new 	BaseResponse();
		try {
			UserVO user=service.cherckUser(accountid);
			if(!StringUtils.isEmpty(user)) {
				response.setCode("999");
				response.setMessage("此用户已存在");
				return response;
			}			
			service.insertUser(accountid,name,branch,position,employeeno,contactno,email,qualification,team);
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode("999");
			response.setMessage("注册失败");
			return response;		  
		}		
		response.setCode("000");
		response.setMessage("注册信息已提交，请等待管理员激活账号");	
		return response;
	}
	
	
	/**用户登陆
	 * @param inputJson
	 * @return
	 * @throws Exception
	 * 用户登录错误上线功能还未做
	 */
	@RequestMapping(value="/login",method = RequestMethod.POST)	
	public  BaseResponse userLogin(@RequestBody String inputJson) throws Exception {		
		String accountid=JsonUtils.getValueByKey(inputJson, "accountid");
		String password=JsonUtils.getValueByKey(inputJson, "password");
		BaseResponse  response=new 	BaseResponse();
		 UserVO  user_VO=null;
		try {
			UserVO user=service.cherckUser(accountid);
			if(StringUtils.isEmpty(user)) {
				response.setCode("997");
				response.setMessage("此用户不存在");
				return response;
			}
		    user_VO=service.userLogin(accountid,password);
			if(StringUtils.isEmpty(user_VO)) {
				response.setCode("998");
				response.setMessage("用户名\\密码错误");
				return response;
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode("999");
			response.setMessage("登录失败");
			return response;		  
		}		
		response.setCode("000");
		response.setMessage("登录成功");	
		response.setObject(user_VO);
		return response;
	}
	
	
	/**用户修改密码
	 * @param inputJson
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/modifypwd",method = RequestMethod.POST)	
	public  BaseResponse userModifyPwd(@RequestBody String inputJson) throws Exception {		
		String accountid=JsonUtils.getValueByKey(inputJson, "accountid");
		String newPassword=JsonUtils.getValueByKey(inputJson, "newPassword");
		BaseResponse  response=new 	BaseResponse();
		try {
		    service.userModifyPwd(accountid,newPassword);		
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode("999");
			response.setMessage("修改密码失败");
			return response;		  
		}		
		response.setCode("000");
		response.setMessage("修改密码成功");	
		return response;
	}
	
	
	/**用户忘记ID或者密码
	 * @param inputJson
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/forgetIdorPwd",method = RequestMethod.POST)	
	public  BaseResponse userForgetIDorPWD(@RequestBody String inputJson) throws Exception {	
		String accountId=JsonUtils.getValueByKey(inputJson, "accountid");
		String email=JsonUtils.getValueByKey(inputJson, "email");
		BaseResponse  response=service.userForgetIDorPWD(accountId,email);
		return response;
	}
	
    
	
	/**根据用户ID查询用户信息
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/getUserByAccountId",method = RequestMethod.GET)	
	public  UserVO getUserByAccountId( HttpServletRequest request)  {	
		String accountId=request.getParameter("accountid");
		UserVO userVO=service.cherckUser(accountId);
		return userVO;
	}
	
}
