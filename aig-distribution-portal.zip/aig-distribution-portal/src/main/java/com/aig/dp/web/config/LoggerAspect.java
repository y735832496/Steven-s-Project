package com.aig.dp.web.config;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.aig.dp.common.util.DateUtils;

/**全局method 日志输出
 * @author 627944
 *
 */
@Order(1)
@Component
@Aspect
public class LoggerAspect {
    public static final Logger log =LoggerFactory.getLogger(LoggerAspect.class);
    
    //控制层拦截,服务层拦截，记录请求的开始，跟请求的结束,
    //第一个*含义是：代表所有类型的返回值，第二个*是代表com.aig.dp.web.controller包下的所有类，
    //第三个是类下的所有方法，括号中两个点表示任意个形参
    @Pointcut("execution(* com.aig.dp.web.controller.*.*(..))||execution(* com.aig.dp.dao.*.*(..))||execution(* com.aig.dp.service.*.*(..))")
    public void controllerPointCut() {

    }
    

    
    /**方法开始时间
     * @param joinPoint
     */
    @Before("controllerPointCut()")
    public void doBefore(JoinPoint joinPoint) {
      //log=LoggerFactory.getLogger(joinPoint.getTarget().getClass());
      log.info("========"+DateUtils.getTimeStr()+"===>开始请求"+joinPoint.getSignature().getDeclaringTypeName()+"."+joinPoint.getSignature().getName()+"==========");
    }
    @AfterThrowing("controllerPointCut()")
    public void doError(JoinPoint joinPoint) {
    	log.info("error");
    }
    
    
    /**服务层方法调用时间
     * @param joinPoint
     * @return
     * @throws Throwable
     */
    @Around("controllerPointCut()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
    	long startTime=System.currentTimeMillis();
    	try {
			Object result=joinPoint.proceed();
			long endTime=System.currentTimeMillis();
			log.info("===>执行" + joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName()
					+ "方法," + parseParames(joinPoint.getArgs()) + ",耗时:" + (endTime - startTime) + " ms!");
			return result;
    	} catch (Throwable e) {
			long endTime = System.currentTimeMillis();
			log.error(joinPoint + ",耗时:" + (endTime - startTime) + " ms,抛出异常 :" + e.getMessage());
			throw e;
		}

    }
    
    
    
    /**方法返回
     * @param ret
     * @throws Throwable
     */
    @AfterReturning(returning = "ret", pointcut = "controllerPointCut()")
	public void doAfterReturning(Object ret) throws Throwable {
		log.info("===>返回值:" + ret);
	}
    
    
    /**方法结束时间
     * @param joinPoint
     */
    @After("controllerPointCut()")
    public void doAfter(JoinPoint joinPoint) {   	
    	   log.info("========"+DateUtils.getTimeStr()+"===>请求"+joinPoint.getSignature().getDeclaringTypeName()+"."+joinPoint.getSignature().getName()+"结束==========");
    }
    
    
    
    //解析参数
    private String parseParames(Object[] parames) {
    	 
		if (null == parames || parames.length <= 0) {
			return "该方法没有参数";
 
		}
		StringBuffer param = new StringBuffer("请求参数 # 个:[ ");
		int i = 0;
		for (Object obj : parames) {
			i++;
			if (i == 1) {
				param.append(obj.toString());
				continue;
			}
			param.append(" ,").append(obj.toString());
		}
		return param.append(" ]").toString().replace("#", String.valueOf(i));
	}
}


