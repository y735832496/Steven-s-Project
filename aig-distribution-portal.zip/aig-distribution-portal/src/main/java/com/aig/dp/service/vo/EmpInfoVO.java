package com.aig.dp.service.vo;

/**
 * @author 686344 Steven
 *	@version 1.0
 *	Date : 20180910
 */

public class EmpInfoVO {
	private int id;
	private String name;
	private String branch;
	private String position; 
	private String alternativePosition;
	private String team;
	private String employeeNo;
	private String contactNo;
	private String emailAccount;
	private String agentQualificationNo; 
	private String producerCodeOrSubCode; 
	private String Status;
	private String isValid;
	/**
	 * @return the isValid
	 */
	public String getIsValid() {
		return isValid;
	}
	/**
	 * @param isValid the isValid to set
	 */
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the position
	 */
	public String getPosition() {
		return position;
	}
	/**
	 * @param position the position to set
	 */
	public void setPosition(String position) {
		this.position = position;
	}
	/**
	 * @return the alternativePosition
	 */
	public String getAlternativePosition() {
		return alternativePosition;
	}
	/**
	 * @param alternativePosition the alternativePosition to set
	 */
	public void setAlternativePosition(String alternativePosition) {
		this.alternativePosition = alternativePosition;
	}
	/**
	 * @return the team
	 */
	public String getTeam() {
		return team;
	}
	/**
	 * @param team the team to set
	 */
	public void setTeam(String team) {
		this.team = team;
	}
	/**
	 * @return the employeeNo
	 */
	public String getEmployeeNo() {
		return employeeNo;
	}
	/**
	 * @param employeeNo the employeeNo to set
	 */
	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}
	/**
	 * @return the contactNo
	 */
	public String getContactNo() {
		return contactNo;
	}
	/**
	 * @param contactNo the contactNo to set
	 */
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	/**
	 * @return the emailAccount
	 */
	public String getEmailAccount() {
		return emailAccount;
	}
	/**
	 * @param emailAccount the emailAccount to set
	 */
	public void setEmailAccount(String emailAccount) {
		this.emailAccount = emailAccount;
	}
	/**
	 * @return the agentQualificationNo
	 */
	public String getAgentQualificationNo() {
		return agentQualificationNo;
	}
	/**
	 * @param agentQualificationNo the agentQualificationNo to set
	 */
	public void setAgentQualificationNo(String agentQualificationNo) {
		this.agentQualificationNo = agentQualificationNo;
	}
	/**
	 * @return the producerCodeOrSubCode
	 */
	public String getProducerCodeOrSubCode() {
		return producerCodeOrSubCode;
	}
	/**
	 * @param producerCodeOrSubCode the producerCodeOrSubCode to set
	 */
	public void setProducerCodeOrSubCode(String producerCodeOrSubCode) {
		this.producerCodeOrSubCode = producerCodeOrSubCode;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return Status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		Status = status;
	}
	

}
