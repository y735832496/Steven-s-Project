package com.aig.dp.dao.sqlserver.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aig.dp.service.vo.EmpInfoVO;
import com.aig.dp.service.vo.UserVO;

public interface EmpInfoSearchMapper {
//	ArrayList<EmpInfoVO> searchEmpInfo(@Param("accountID") String accountid);

	//List queryUserByMuiltfield(@Param("accountId")String accountId, @Param("name")String name, @Param("branch")String branch, @Param("team")String team, @Param("premium") String premium, @Param("status")String status, @Param("annual") String annual);
	
	UserVO modifyEmpInfo(@Param("accountId") String accountId);
	
	public void updateEmpInfo(@Param("accountId") String accountId,@Param("name") String name,@Param("branch") String branch,@Param("position")String position,@Param("employeeNo")String employeeNo,
			@Param("contactNo") String contactNo,@Param("email") String email,@Param("qualification") String qualification,@Param("team") String team);
	
	public ArrayList<UserVO> teamMemberSearch(@Param("team")String team);
}
