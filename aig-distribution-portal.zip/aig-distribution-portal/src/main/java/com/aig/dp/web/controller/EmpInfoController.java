package com.aig.dp.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.aig.dp.common.uibinding.BaseResponse;
import com.aig.dp.common.util.JsonUtils;
import com.aig.dp.service.index.EmpInfoService;
import com.aig.dp.service.vo.PresidentCupVO;
import com.aig.dp.service.vo.UserVO;

/**
 * @author 686344 Steven
 *20180911
 */
@Controller
public class EmpInfoController {

	
	public static final Logger log = LoggerFactory.getLogger(EmpInfoController.class);

	
	@Autowired
	protected EmpInfoService service;


	/**
	 * 管理员修改员工密码
	 * @author 686344
	 * @param inputJson
	 * @return user
	 * @throws Exception
	 */
	@RequestMapping(value="/modifyEmpInfo",method=RequestMethod.POST)
	@ResponseBody
	public UserVO modifyEmpInfo(@RequestBody String inputJson) throws Exception {
		String accountId=JsonUtils.getValueByKey(inputJson, "accountId");
		UserVO user=service.modifyEmpInfo(accountId);
		if(user == null)
		{
			UserVO userTemp = new UserVO();
			userTemp.setExist("false");
			return userTemp;
		}
		return user;
	}
	
	/**
	 * update employee's information
	 * @author 686344
	 * @param inputJson
	 * @return response
	 * @throws Exception
	 */
	@RequestMapping(value="/updateEmpInfo",method=RequestMethod.POST)
	@ResponseBody
	public BaseResponse updateEmpInfo(@RequestBody String inputJson) throws Exception {
		String accountId=JsonUtils.getValueByKey(inputJson, "accountId");
		String name = JsonUtils.getValueByKey(inputJson, "name");
		String branch = JsonUtils.getValueByKey(inputJson, "branch");
		String position = JsonUtils.getValueByKey(inputJson, "position");
		String employeeNo = JsonUtils.getValueByKey(inputJson, "employeeNo");
		String contactNo = JsonUtils.getValueByKey(inputJson, "contactno");
		String email = JsonUtils.getValueByKey(inputJson, "email");
		String qualification = JsonUtils.getValueByKey(inputJson, "qualification");
		String team = JsonUtils.getValueByKey(inputJson, "team");
		BaseResponse response = new BaseResponse();
		try {
		service.updateEmpInfo(accountId, name, branch, position, employeeNo, contactNo, email, qualification, team);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			response.setCode("999");
			response.setMessage("更新失败");
		}
		response.setCode("000");
		response.setMessage("更新成功");
		
		
		return response;
	}
	
	/**查询团队信息
	 * @author 627944
	 * @param inputJson
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/queryUserByMuiltfield",method=RequestMethod.POST)
	public ModelAndView queryUserByMuiltfield(@RequestBody String inputJson) throws Exception {
		String accountId=JsonUtils.getValueByKey(inputJson, "accountid");
		String name=JsonUtils.getValueByKey(inputJson, "name");
		String branch=JsonUtils.getValueByKey(inputJson, "branch");
		String team=JsonUtils.getValueByKey(inputJson, "team");
		String premium=JsonUtils.getValueByKey(inputJson, "premium");
		String status=JsonUtils.getValueByKey(inputJson, "status");
		String annual=JsonUtils.getValueByKey(inputJson, "annual");
		List  userList=service.queryUserByMuiltfield(accountId,name,branch,team,premium,status,annual);
		return null;
	}
	
	/** 团队员工检索
	 * @author 686344
	 * @param inputJSON
	 * @return list
	 */
	@RequestMapping(value="/teamMemberPage",method=RequestMethod.POST)
	@ResponseBody
	public BaseResponse teamMemberPage(@RequestBody String inputJSON) throws Exception{
		String team=JsonUtils.getValueByKey(inputJSON, "team");
		BaseResponse baseResponse = new BaseResponse();
		List<UserVO> list = new ArrayList<UserVO>();
		list = service.teamMemberSearch(team);
		if(list.isEmpty()){
			baseResponse.setMessage("您所在团队中无成员");
			baseResponse.setCode("998");
		}
		else {
			baseResponse.setMessage("检索成功");
			baseResponse.setCode("000");
		}
		baseResponse.setObject(list);
		return baseResponse;
	}
	
	@SuppressWarnings("serial")
	@RequestMapping(value="/test",method=RequestMethod.POST)
	@ResponseBody
	public BaseResponse test(Model model) throws Exception{

        List<HashMap<String, Object>> resultList = new ArrayList<HashMap<String, Object>>();
        HashMap<String, Object> student = new HashMap<String, Object>(){{
            put("sid", "101");
            put("sname", "张三");
            put("sage", "20");
            put("scourse", new HashMap<String, String>(){{
                put("cname", "语文,数学,英语");
                put("cscore", "93,95,98");
            }});
        }};
        resultList.add(student);
        student = new HashMap<String, Object>(){{
            put("sid", "102");
            put("sname", "李四");
            put("sage", "30");
            put("scourse", new HashMap<String, String>(){{
                put("cname", "物理,化学,生物");
                put("cscore", "92,93,97");
            }});
        }};
        resultList.add(student);
        model.addAttribute("resultList", resultList);

	BaseResponse baseResponse = new BaseResponse();
	baseResponse.setCode("000");
	
		return baseResponse;
	}
	
	
	
}
