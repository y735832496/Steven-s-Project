package com.aig.dp.common.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**通用时间处理工具类
 * @author 627944
 *
 */
public class DateUtils {
      
	public static final String  format="yyyy-MM-dd HH:mm:ss";
	
	public static String  getTimeStr() {
		Calendar calendar=Calendar.getInstance();
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat(format);
		return 	simpleDateFormat.format(calendar.getTime());
	}
}
