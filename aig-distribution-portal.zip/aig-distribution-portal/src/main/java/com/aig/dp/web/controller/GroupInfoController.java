package com.aig.dp.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aig.dp.common.uibinding.BaseResponse;
import com.aig.dp.common.util.JsonUtils;
import com.aig.dp.service.index.GroupInfoService;
import com.aig.dp.service.vo.UserVO;

@Controller
public class GroupInfoController {
	
	@Autowired
	protected GroupInfoService service;

	@RequestMapping(value="/empSearchInGroup",method=RequestMethod.POST)
	@ResponseBody
	public BaseResponse empSearchInGroup(@RequestBody String inputJSON) throws Exception{
		String name = JsonUtils.getValueByKey(inputJSON, "name");
		String employeeNo = JsonUtils.getValueByKey(inputJSON, "employeeNo");
		String branch = JsonUtils.getValueByKey(inputJSON, "branch");
		String team = JsonUtils.getValueByKey(inputJSON, "team");
		String annual = JsonUtils.getValueByKey(inputJSON, "annual");
//		String team=JsonUtils.getValueByKey(inputJSON, "team");
		BaseResponse baseResponse = new BaseResponse();
		List<UserVO> list = new ArrayList<UserVO>();
		list = service.empSearch(name,employeeNo,branch,team,annual);
		baseResponse.setObject(list);
		return baseResponse;
	}
}
