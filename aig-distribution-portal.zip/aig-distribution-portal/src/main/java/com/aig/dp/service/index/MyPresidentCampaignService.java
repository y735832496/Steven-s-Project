package com.aig.dp.service.index;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aig.dp.dao.sqlserver.mapper.PresidentCupMapper;
import com.aig.dp.service.vo.PresidentCupVO;

@Service
public class MyPresidentCampaignService {

	@Autowired
	PresidentCupMapper dao;
	
	public PresidentCupVO myPCC(String branch,String team,String employeeNo)
	{
		PresidentCupVO pcVO = new PresidentCupVO();
		pcVO=dao.myPresidentCupSearch(branch,team,employeeNo);
		return pcVO;
	}
	
	
}
