package com.aig.dp;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication/*(exclude = {
        DataSourceAutoConfiguration.class
})*/
@EnableAsync 
@MapperScan("com.aig.dp.dao.sqlserver")

public class DistributionPortalApp extends SpringBootServletInitializer{
    
/*	//mian启动方式
	public static void main(String[] args) {
		SpringApplication.run(DistributionPortalApp.class, args); 
	}*/
	
	//war包运行方式
	  @Override  
	  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {  
	        return application.sources(DistributionPortalApp.class);  
	    }  
	  public static void main(String[] args) throws Exception {
	        SpringApplication.run(DistributionPortalApp.class, args);
	    }
}