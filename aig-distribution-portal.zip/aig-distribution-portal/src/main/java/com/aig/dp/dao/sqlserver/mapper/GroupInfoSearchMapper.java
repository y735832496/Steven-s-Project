package com.aig.dp.dao.sqlserver.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.aig.dp.service.vo.UserVO;

public interface GroupInfoSearchMapper {
	public ArrayList<UserVO> empSearch(@Param("name")String name,@Param("employeeNo")String employeeNo,
			@Param("branch")String branch,@Param("team")String team,@Param("annual")String annual);
	
}
