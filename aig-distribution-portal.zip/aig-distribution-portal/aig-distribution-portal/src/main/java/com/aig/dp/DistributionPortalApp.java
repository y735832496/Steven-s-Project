package com.aig.dp;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.aig.dp.dao.sqlserver")
public class DistributionPortalApp {

	public static void main(String[] args) {
		SpringApplication.run(DistributionPortalApp.class, args);
	}
}