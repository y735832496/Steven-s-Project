package com.aig.dp.common.uibinding;

public class BaseResponse {
    protected String code;
    protected String message;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void setCodeMessage(String key,String msg)
	{
		this.code=key;
		this.message=msg;
	}
    
}
