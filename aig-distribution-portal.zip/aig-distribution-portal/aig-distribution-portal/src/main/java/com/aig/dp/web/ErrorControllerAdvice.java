package com.aig.dp.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.aig.dp.common.exception.ExceptionUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * controller 增强器
 *
 * @author sam
 * @since 2017/7/17
 */
@ControllerAdvice
public class ErrorControllerAdvice {
	private final Logger logger = LoggerFactory.getLogger(ErrorControllerAdvice.class);
    /**
     * 全局异常捕捉处理
     * @param ex
     * @return

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Map restErrorHandler(Exception ex) {
        Map map = new HashMap();
        map.put("code", 100);
        map.put("msg", ex.getMessage());
        return map;
    }         */

    @ExceptionHandler(value = Exception.class)
    public ModelAndView pageErrorHandler(Exception ex) {
    	logger.info("*******************capture by ErrorControllerAdvice******************************");
    	String exStr=ExceptionUtil.getExceptionStack(ex);
    	logger.info(exStr);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        modelAndView.addObject("code", 100);
        modelAndView.addObject("msg", ex.getMessage());
        return modelAndView;
    }
}