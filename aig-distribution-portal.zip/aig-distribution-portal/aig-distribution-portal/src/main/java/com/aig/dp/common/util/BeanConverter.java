package com.aig.dp.common.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BeanConverter {
	private static Logger logger = LoggerFactory.getLogger(BeanConverter.class);
	
	public static<M,N> List<N> toVOList(List<M> inputList, Class<N> voType) throws Exception
	{
		List<N> outputList=new ArrayList<N>();
		for(M inputObj : inputList)
		{
			N outputObj=voType.newInstance();
			BeanUtils.copyProperties(outputObj, inputObj);
			outputList.add(outputObj);
		}
		return outputList;
	}
	
	public static<M,N> N toVO(M inputObj, Class<N> voType) throws Exception
	{
		N outputObj=voType.newInstance();
		BeanUtils.copyProperties(outputObj, inputObj);
		return outputObj;
	}
}
