package com.aig.dp.common.uibinding;

import java.util.List;

public class ListResponse<T> extends BaseResponse{
	private List<T> list;

	public List<T> getList() {
		return list;
	}

	public void setList(List<T> list) {
		this.list = list;
	}
	
	
}
