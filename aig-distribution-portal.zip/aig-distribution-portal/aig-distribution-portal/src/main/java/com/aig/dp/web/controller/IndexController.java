package com.aig.dp.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.aig.dp.service.index.IndexService;
import com.aig.dp.service.vo.UserVO;


@Controller
@RequestMapping("/dp")
public class IndexController {
	
	@Autowired
	protected IndexService service;
	
	/**
	 * 跳转页面 传数据方法
	 * @param model
	 * @return
	 * @throws Exception 
     */
	@RequestMapping("/index")
	public String index(Model model) throws Exception {
		UserVO obj=service.getPersonsByID();
		model.addAttribute("person",obj);
        List<UserVO> list=service.getPersons();
        
		model.addAttribute("list",list);
		//返回 index.html页面
		return "index";
	}
	
	@RequestMapping("/home")
	public String home() throws Exception {
	    throw new Exception("this is a test exception");
	}
}

