package com.aig.dp.common.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;


public class HttpServletUtil {
	/**
	 * 创建日期:2018年4月6日<br/>
	 * 代码创建:黄聪<br/>
	 * 功能描述:通过request来获取到json数据<br/>
	 * @param request
	 * @return
	 * @throws IOException 
	 */
	public static String getJSONString(HttpServletRequest request) throws IOException{
	    InputStream inputStream=request.getInputStream();
	    InputStreamReader inputStreamReader=new InputStreamReader(inputStream);
        // 获取输入流
        BufferedReader streamReader = new BufferedReader(inputStreamReader);

        // 写入数据到Stringbuilder
        StringBuilder sb = new StringBuilder();
        String line = null;
        while ((line = streamReader.readLine()) != null) {
            sb.append(line);
        }
        // 直接将json信息打印出来
        System.out.println(sb.toString());
	    return sb.toString();
	}
	
	public static void writeResponse(Object result,HttpServletResponse res) 
	{
		try
		{
			ObjectMapper mapper=new ObjectMapper();
			String json=mapper.writeValueAsString(result);
	    	PrintWriter out=res.getWriter();
	    	out.write(json);
	        out.flush();
	        out.close();
			//String url=this.memCache.getParam(ParamCont.AEMURL_LoginPage);
			//res.sendRedirect(url);
		}
		catch(IOException ioEx)
		{
            System.out.println(ioEx);
		}
	}
	
    public static void writeCrossDomainHeader(HttpServletResponse response)
    {
    	response.setCharacterEncoding("UTF-8");  
        response.setContentType("application/json;charset=UTF-8");
        response.setHeader("Access-Control-Allow-Origin", "*");  
        response.setHeader("Access-Control-Allow-Methods", "PUT, POST, GET, OPTIONS, DELETE");  
        response.setHeader("Access-Control-Max-Age", "3600");  
        response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type,token"); 
    }
}
