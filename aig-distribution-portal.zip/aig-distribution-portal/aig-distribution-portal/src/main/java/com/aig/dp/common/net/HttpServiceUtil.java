package com.aig.dp.common.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.rmi.ServerException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

import org.apache.ibatis.mapping.Environment;



public class HttpServiceUtil {

    
    public static String httpRequest(String requestUrl,String requestMethod,String outputStr,String type) throws Exception{  
        StringBuffer buffer=null;  
        try{  
	        URL url=new URL(requestUrl);  
	        HttpURLConnection conn=(HttpURLConnection)url.openConnection();  
	        conn.setRequestProperty("Content-Type", "application/xml; charset=UTF-8");
	        conn.setDoOutput(true);  
	        conn.setDoInput(true);  
	        conn.setRequestMethod(requestMethod);  
	        conn.connect();  
	        //往服务器端写内容 也就是发起http请求需要带的参数  
	        if(null!=outputStr){  
	            OutputStream os=conn.getOutputStream();  
	            os.write(outputStr.getBytes("utf-8"));  
	            os.close();  
	        }  
	         
	        //读取服务器端返回的内容  
	        InputStream is=conn.getInputStream();  
	        InputStreamReader isr=new InputStreamReader(is,"utf-8");  
	        BufferedReader br=new BufferedReader(isr);  
	        buffer=new StringBuffer();  
	        String line=null;  
	        while((line=br.readLine())!=null){  
	            buffer.append(line);  
	        }  
        }
        catch(Exception e){  
            throw e;
        }  

        return buffer.toString();  
    }  
	
    
    /*public static void main(String[] args) throws  ServerException {  
	String a =("{\"clientNum\":\"*\",\"agentCode\":\"SH30580\"}"); 
    String url="http://127.0.0.1:8081/PerIns";  
        //String data=GetJsonData.getJsonData(a ,url);  
        
         //data=GetJsonData.getJsonData(a ,url); 
    String result =InterfaceCall.doPost(url); 
    System.out.println("解压后~~~~~~~~~~~~~"+result);
                //返回的是一个[{}]格式的字符串时:                                 
            //JSONArray jsonArray = new JSONArray(data);                         
               //返回的是一个{}格式的字符串时:                         
               JSONObject obj= new JSONObject(data);        
    }  */

/**  
2.	     * 向指定 URL 发送POST方法的请求  
3.	     *  
4.	     * @param url   发送请求的 URL  
5.	     * @return 所代表远程资源的响应结果  
6.	     * @throws Exception  
7.	     
 * @throws IOException */  
   public static String doPost(String url) throws IOException {  
	        PrintWriter out = null;  
    BufferedReader in = null;  
	        String result = "";  
	        InputStream ism = null;  
        HttpURLConnection conn = null;  
        try {  
            URL realUrl = new URL(url);  
	            // 打开和URL之间的连接  
	            conn = (HttpURLConnection) realUrl  
	                    .openConnection();  
            // 设置通用的请求属性  
	            conn.setRequestProperty("accept", "*/*");  
            conn.setRequestProperty("connection", "Keep-Alive");  
	            conn.setRequestMethod("POST");  
	            //conn.setRequestProperty("contentType", "application/x-www-form-urlencoded");  
	            conn.setRequestProperty("contentType", "application/json"); 
            conn.setRequestProperty("charset", "utf-8");  
	            conn.setRequestProperty("Accept-Encoding", "gzip");//gzip  
	            conn.setUseCaches(false);  
            // 发送POST请求必须设置如下两行  
            conn.setDoOutput(true);  
	            conn.setDoInput(true);  
//	            conn.setReadTimeout(TIMEOUT_IN_MILLIONS);  
//	            conn.setConnectTimeout(TIMEOUT_IN_MILLIONS);  
//	            String param = "";  
//	            for (Map.Entry p : map.entrySet()) {  
//                param += (param == "" ? "" : "&") + p.getKey() + "=" + p.getValue();  
//	            }  
	            
	                // 获取URLConnection对象对应的输出流  
	                out = new PrintWriter(conn.getOutputStream());  
                // 发送请求参数  
	  
	                out.print("");//使用url编码  
                // flush输出流的缓冲  
	                out.flush();  
	                //5.得到服务器相应  
	                if (conn.getResponseCode() == 200) {  
                    System.out.println("服务器已经收到表单数据！");  
	                } else {  
	                    System.out.println("请求失败！");  
	                }  
       
	            String encoding = conn.getContentEncoding();  
            ism = conn.getInputStream();  
            
//            in = new BufferedReader(  
//                    new InputStreamReader(ism));  
//            String line;  
//            while ((line = in.readLine()) != null) {  
//                result += line;  
//            }  
//            System.out.println("解压 前~~~~~~~~~~~~~"+result);
        if (encoding != null && encoding.contains("gzip")) {//首先判断服务器返回的数据是否支持gzip压缩，  
                //如果支持则应该使用GZIPInputStream解压，否则会出现乱码无效数据  
        	
                ism = new GZIPInputStream(conn.getInputStream());  
            }  
            // 定义BufferedReader输入流来读取URL的响应  
            in = new BufferedReader(  
                    new InputStreamReader(ism));  
            String line="";  
            result="";
            while ((line = in.readLine()) != null) {  
                result += line;  
            }  
	        } catch (Exception e) {  
            e.printStackTrace();  
	            throw new ServerException("服务器错误");  
        }  
        
    // 使用finally块来关闭输出流、输入流  
        finally {  
            try {  
                if (out != null) {  
                    out.close();  
                }  
            if (in != null) {  
                    in.close();  
	                }  
	                if (conn != null) {  
                conn.disconnect();  
	                }  
	  
	            } catch (IOException ex) {  
	                throw ex;
	            }  
	        }  
	        return result;  
	    } 
   
   
   
   /**
    * 描述:  发起https请求并获取结果
    * @param requestUrl 请求地址
    * @param requestMethod 请求方式（GET、POST）
    * @param outputStr 提交的数据
    * @return JSONObject(通过JSONObject.get(key)的方式获取json对象的属性值)
 * @throws Exception 
    */
   public static String httpSSLRequest(String requestUrl, String requestMethod, String outputStr,String headerKey,String headerValue) throws Exception {
	   String jsonObject = null;
       StringBuffer buffer = new StringBuffer();
       try {
           // 创建SSLContext对象，并使用我们指定的信任管理器初始化
           TrustManager[] tm = { new MyX509TrustManager() };
           SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");
           sslContext.init(null, tm, new java.security.SecureRandom());
           // 从上述SSLContext对象中得到SSLSocketFactory对象
           SSLSocketFactory ssf = sslContext.getSocketFactory();

           URL url = new URL(requestUrl);
           HttpsURLConnection httpUrlConn = (HttpsURLConnection) url.openConnection();
           httpUrlConn.setRequestProperty(headerKey, headerValue);
           httpUrlConn.setSSLSocketFactory(ssf);

           httpUrlConn.setDoOutput(true);
           httpUrlConn.setDoInput(true);
           httpUrlConn.setUseCaches(false);
           // 设置请求方式（GET/POST）
           httpUrlConn.setRequestMethod(requestMethod);

           if ("GET".equalsIgnoreCase(requestMethod))
               httpUrlConn.connect();

           // 当有数据需要提交时
           if (null != outputStr) {
               OutputStream outputStream = httpUrlConn.getOutputStream();
               // 注意编码格式，防止中文乱码
               outputStream.write(outputStr.getBytes("UTF-8"));
               outputStream.close();
           }

           // 将返回的输入流转换成字符串
           InputStream inputStream = httpUrlConn.getInputStream();
           InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
           BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

           String str = null;
           while ((str = bufferedReader.readLine()) != null) {
               buffer.append(str);
           }
           bufferedReader.close();
           inputStreamReader.close();
           // 释放资源
           inputStream.close();
           inputStream = null;
           httpUrlConn.disconnect();
           jsonObject = buffer.toString();
       } catch (ConnectException ce) {
           throw ce;
       } catch (Exception e) {
           throw e;
       }
       return jsonObject;
   }
}
