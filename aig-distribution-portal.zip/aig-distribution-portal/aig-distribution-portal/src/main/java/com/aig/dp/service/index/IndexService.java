package com.aig.dp.service.index;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aig.dp.common.util.BeanConverter;
import com.aig.dp.dao.sqlserver.po.User;
import com.aig.dp.dao.sqlserver.mapper.UserMapper;
import com.aig.dp.service.BaseService;
import com.aig.dp.service.vo.UserVO;

@Service
public class IndexService extends BaseService{
	@Autowired
	protected UserMapper dao;
	
    public List<UserVO> getPersons() throws Exception
    {   	 
        List<User> poList=this.dao.getPersons();
        List<UserVO> list=BeanConverter.toVOList(poList, UserVO.class);
        return list;
    }
    
    public UserVO getPersonsByID() throws Exception
    {
    	User obj=this.dao.getPersonsByID(1);
    	UserVO vo=BeanConverter.toVO(obj, UserVO.class);
        return vo;
    }
}
