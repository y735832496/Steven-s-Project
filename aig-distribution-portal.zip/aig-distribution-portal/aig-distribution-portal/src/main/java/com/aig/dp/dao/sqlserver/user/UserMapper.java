package com.aig.dp.dao.sqlserver.mapper;

import java.util.List;
import com.aig.dp.dao.sqlserver.po.User;


public interface UserMapper { 
    public List<User> getPersons() throws Exception;
    
    public User getPersonsByID(int id) throws Exception;
}