package com.aig.dp.service.vo;


/**
 * 描述：实体类
 *
 * @author
 * @create_time
 */
public class UserVO {
 
    private String name;
 
    private String description;
 
    public UserVO(String name, String description) {
        this.name = name;
        this.description = description;
    }
 
    public UserVO() {

    }
    
    public String getDescription() {
        return this.description;
    }
 
    public void setDescription(String description) {
        this.description = description;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
}
