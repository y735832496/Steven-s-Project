package com.aig.dp.web.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
@Configuration
public class ReadLocalConfig {
	@Autowired
    public Environment env;
	
	public void readDetail() {
		System.out.println("******************************");
		String url=env.getProperty("spring.datasource.url");
		String username=env.getProperty("spring.datasource.username");
		String password=env.getProperty("spring.datasource.password");
		String driver=env.getProperty("spring.datasource.driver");
		System.out.println(url+username+password);
		System.out.println("******************************");
	}
	
 
	
		
	

}
