package com.aig.dp.common.util;

import java.util.Random;

public class StringUtils {

	
	public static boolean isEmpty(String arg) {
		if (arg == null || arg.trim().length() < 1) {
			return true;
		}
		else {
			return false;
		}
	}

    public static String getRandom()
    {
    	Random random = new Random();
    	String result="";
    	for (int i=0;i<6;i++)
    	{
    		result+=random.nextInt(10);
    	}
    	System.out.println(result);
        return result;

    }
	
	
}

