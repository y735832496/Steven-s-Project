package com.aig.dp.common.uibinding;

public class BaseRequest {

    
    
}
