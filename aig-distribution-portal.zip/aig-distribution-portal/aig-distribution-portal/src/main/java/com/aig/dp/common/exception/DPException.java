package com.aig.dp.common.exception;

public class DPException extends Exception {

    public DPException(String message) {
        super(message);
    }
    
}