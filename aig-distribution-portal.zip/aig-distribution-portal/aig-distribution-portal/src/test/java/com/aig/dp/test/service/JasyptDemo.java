package com.aig.dp.test.service;
import java.io.PrintStream;
import java.util.Scanner;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
public class JasyptDemo {
	 
	/*  public static final String key="security";*/
	  public static void main(String[] args)
	  {
	    Scanner reader = new Scanner(System.in);
	    System.out.println("please enter KEY :");
	    String key = reader.next();
	    System.out.println("please enter DB_Account: ");
	    String account = reader.next();
	    System.out.println("please enter DB_Password: ");
	    String passwrod = reader.next();
	    String ciphertext1 = encrypt(key, account);
	    String ciphertext2 = encrypt(key, passwrod);
	    String ciphertext3 = decrypt(key, ciphertext1);
	    String ciphertext4 = decrypt(key, ciphertext2);
	    
	    System.out.println("Encode account:" + ciphertext1);
	    System.out.println("Encode password:" + ciphertext2);
	    System.out.println("Decode account:" + ciphertext3);
	    System.out.println("Decode password:" + ciphertext4);
	  }
	  
	  public static String encrypt(String key, String text)
	  {
	    StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
	    encryptor.setPassword(key);
	    return encryptor.encrypt(text);
	  }
	  
	  public static String decrypt(String key, String ciphertext)
	  {
	    StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
	    encryptor.setPassword(key);
	    return encryptor.decrypt(ciphertext);
	  }	
}
