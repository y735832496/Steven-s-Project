package com.aig.dp.test.service;

import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;



/**tomcat默认连接池的配置
 * @author 627944
 *
 */
public class TomcatTest {	 		 	 
	    public static final int DEFAULT_MAX_ACTIVE = 100;
	 
	    protected static final AtomicInteger poolCounter = new AtomicInteger(0);
	    private volatile Properties dbProperties = new Properties();
	    private volatile String url = null;
	    private volatile String driverClassName = null;
	    private volatile Boolean defaultAutoCommit = null;
	    private volatile Boolean defaultReadOnly = null;
	   // private volatile int defaultTransactionIsolation = DataSourceFactory.UNKNOWN_TRANSACTIONISOLATION;
	    private volatile String defaultCatalog = null;
	    private volatile String connectionProperties;
	    private volatile int initialSize = 10;
	    private volatile int maxActive = DEFAULT_MAX_ACTIVE;
	    private volatile int maxIdle = maxActive;
	    private volatile int minIdle = initialSize;
	    private volatile int maxWait = 30000;
	    private volatile String validationQuery;
	    private volatile int validationQueryTimeout = -1;
	    private volatile String validatorClassName;
	   // private volatile Validator validator;
	    private volatile boolean testOnBorrow = false;
	    private volatile boolean testOnReturn = false;
	    private volatile boolean testWhileIdle = false;
	    private volatile int timeBetweenEvictionRunsMillis = 5000;
	    private volatile int numTestsPerEvictionRun;
	    private volatile int minEvictableIdleTimeMillis = 60000;
	    private volatile boolean accessToUnderlyingConnectionAllowed = true;
	    private volatile boolean removeAbandoned = false;
	    private volatile int removeAbandonedTimeout = 60;
	    private volatile boolean logAbandoned = false;
	  //  private volatile String name = "Tomcat Connection Pool["+(poolCounter.addAndGet(1))+"-"+System.identityHashCode(PoolProperties.class)+"]";
	    private volatile String password;
	    private volatile String username;
	    private volatile long validationInterval = 3000;
	    private volatile boolean jmxEnabled = true;
	    private volatile String initSQL;
	    private volatile boolean testOnConnect =false;
	    private volatile String jdbcInterceptors=null;
	    private volatile boolean fairQueue = true;
	    private volatile boolean useEquals = true;
	    private volatile int abandonWhenPercentageFull = 0;
	    private volatile long maxAge = 0;
	    private volatile boolean useLock = false;
	   // private volatile InterceptorDefinition[] interceptors = null;
	    private volatile int suspectTimeout = 0;
	    private volatile Object dataSource = null;
	    private volatile String dataSourceJNDI = null;
	    private volatile boolean alternateUsernameAllowed = false;
	    private volatile boolean commitOnReturn = false;
	    private volatile boolean rollbackOnReturn = false;
	    private volatile boolean useDisposableConnectionFacade = true;
	    private volatile boolean logValidationErrors = false;
	    private volatile boolean propagateInterruptState = false;
	    private volatile boolean ignoreExceptionOnPreLoad = false;
	    private volatile boolean useStatementFacade = true;

}
