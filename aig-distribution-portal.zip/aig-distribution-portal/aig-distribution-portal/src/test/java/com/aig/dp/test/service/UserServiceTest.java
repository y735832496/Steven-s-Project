package com.aig.dp.test.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aig.dp.DistributionPortalApp;
import com.aig.dp.dao.sqlserver.po.User;


@RunWith(SpringRunner.class)
@SpringBootTest(classes=DistributionPortalApp.class)
public class UserServiceTest {
    public List<User> getPersons()
    {   	 
    	List<User> list = new ArrayList<>();

    	User p1 = new User("aa","sdgsdg");
    	User p2 = new User("bb","sdgsdg");
    	User p3 = new User("cc","sdgsdg");
    	User p4 = new User("dd","sdgsdg");

    	list.add(p1);
    	list.add(p2);
    	list.add(p3);
    	list.add(p4);
    	
    	return list;
    }
    
    public User getPersonsByID()
    {
    	User obj = new User("张三","sdgsdg");
        return obj;
    }
}
